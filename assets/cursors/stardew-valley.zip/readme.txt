﻿=== Stardew Valley Cursor Set ===

By: Frog_Lilly (http://www.rw-designer.com/user/94926) lillianismyname@gmail.com

Download: http://www.rw-designer.com/cursor-set/stardew-valley

Author's description:

I really wanted a stardew valley cursor set, but there weren't any, so I decided to make one! I hope you like it :D Please let me know if there are any issues


==========

License: Creative Commons - Attribution

You are free:

* To Share - To copy, distribute and transmit the work.
* To Remix - To adapt the work.

Under the following conditions:

* Attribution - You must attribute the work in the manner specified
  by the author or licensor (but not in any way that suggests that
  they endorse you or your use of the work). For example, if you are
  making the work available on the Internet, you must link to the
  original source.